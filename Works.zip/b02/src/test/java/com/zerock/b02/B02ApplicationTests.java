package com.zerock.b02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class B02ApplicationTests {

    @Test
    void contextLoads() {
    }

}
