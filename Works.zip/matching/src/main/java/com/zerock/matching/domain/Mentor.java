package com.zerock.matching.domain;

import com.zerock.matching.dto.MentorDTO;
import lombok.*;

import javax.persistence.*;

@Entity
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Mentor extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "mentoringId")
    private Long menNo;              // 멘토링번호

    @OneToOne
    @JoinColumn(name = "memberId")
    private Member member;

    @Column(length = 100, nullable = false)
    private String title;           // 제목

    @Column(length = 2000, nullable = false)
    private String content;         // 내용

    @Column(length = 50, nullable = false)
    private String meetingTime;     // 시간

    @Column(length = 50, nullable = false)
    private String price;           // 금액

    @Column(length = 50, nullable = false)
    private String duty;            // 직무

    @Column(length = 50, nullable = false)
    private String career;          // 경력

    @Column(length = 50, nullable = false)
    private String company;         // 회사

    public static MentorDTO entityToDTO(Mentor mentor){
        MentorDTO mentorDTO = MentorDTO.builder()
                .mentorId(mentor.member.getId())
                .title(mentor.title)
                .content(mentor.content)
                .meetingTime(mentor.meetingTime)
                .price(mentor.price)
                .duty(mentor.duty)
                .career(mentor.career)
                .company(mentor.company)
                .build();
        return mentorDTO;
    }

    public void change(String title, String content, String meetingTime, String price){
        this.title = title;
        this.content = content;
        this.meetingTime = meetingTime;
        this.price = price;
    }
}
