package com.zerock.matching.domain;


import lombok.*;

import javax.persistence.*;

@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
public class Member {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long mno;

    @Id
    @Column(name="memberId")
    private String id;

    @Column
    private String pw;

    @Column
    private String email;

    @Column
    private String phone;

    @Column
    private String address;

    @OneToOne(mappedBy = "mentor")
    private Mentor mentor;
}
