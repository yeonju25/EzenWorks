package com.zerock.matching.service;

import org.springframework.stereotype.Service;

@Service
public interface MatchingService {

    public void insert();   //멤버 등록
    public void readOne();  //멤버 한명 읽기

    public void modify();   //멤버 수정

    public void list();     //list 전체 불러오기용
    public void delete();   //  삭제 용;
}
