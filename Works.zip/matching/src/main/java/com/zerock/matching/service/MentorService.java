package com.zerock.matching.service;

import com.zerock.matching.dto.MentorDTO;

import java.util.List;

public interface MentorService {
    void register(MentorDTO mentorDTO);

    MentorDTO readOne(Long menNO);

    void modify(MentorDTO mentorDTO);

    void remove(Long menNo);

    List<MentorDTO> list();








}
