package com.zerock.matching.service;

import com.zerock.matching.domain.Mentor;
import com.zerock.matching.dto.MentorDTO;
import com.zerock.matching.repository.MentorRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Log4j2
@RequiredArgsConstructor
@Transactional
public class MentorServiceImpl implements MentorService{

    private final MentorRepository mentorRepository;


    @Override
    public void register(MentorDTO mentorDTO) {
        Mentor mentor = Mentor.builder()
                .title(mentorDTO.getTitle())
                .content(mentorDTO.getContent())
                .meetingTime(mentorDTO.getMeetingTime())
                .price(mentorDTO.getPrice())
                .duty(mentorDTO.getDuty())
                .career(mentorDTO.getCareer())
                .company(mentorDTO.getCompany())
                .build();

        mentorRepository.save(mentor);
    }

    @Override
    public MentorDTO readOne(Long menNO) {
        Optional<Mentor> byId = mentorRepository.findById(menNO);
        Mentor mentor = byId.orElseThrow();
        MentorDTO mentorDTO = MentorDTO.builder()
                .mentorId(mentor.getMember().getId())
                .title(mentor.getTitle())
                .content(mentor.getContent())
                .meetingTime(mentor.getMeetingTime())
                .price(mentor.getPrice())
                .duty(mentor.getDuty())
                .career(mentor.getCareer())
                .company(mentor.getCompany())
                .build();
        return mentorDTO;
    }

    @Override
    public void modify(MentorDTO mentorDTO) {
        Optional<Mentor> byId = mentorRepository.findById(mentorDTO.getMenNo());
        Mentor mentor = byId.orElseThrow();
        mentor.change(mentorDTO.getTitle(), mentorDTO.getContent(),
                mentorDTO.getMeetingTime(), mentorDTO.getPrice());
        mentorRepository.save(mentor);
    }

    @Override
    public void remove(Long menNo) {
        mentorRepository.deleteById(menNo);
    }

    @Override
    public List<MentorDTO> list() {
        List<Mentor> list = mentorRepository.findAll();
        List<MentorDTO> dtoList = list.stream()
                .map(Mentor::entityToDTO)
                .collect(Collectors.toList());
        return dtoList;
    }


}
