package com.zerock.matching.repository;

import com.zerock.matching.domain.Member;
import com.zerock.matching.domain.Mentor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MentorRepository extends JpaRepository<Mentor, Long> {

}
