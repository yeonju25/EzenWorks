package com.zerock.matching.dto;

import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MentorDTO {

    private Long menNo;              // 멘토링번호

    private String mentorId;        // 멘토아이디

    private String title;           // 제목

    private String content;         // 내용

    private String meetingTime;     // 시간

    private String price;           // 금액

    private String duty;            // 직무

    private String career;          // 경력

    private String company;         // 회사



}
