package com.zerock.matching.service;


import com.zerock.matching.repository.MatchingRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@RequiredArgsConstructor
public class MatchingServiceImpl implements MatchingService{


    private final MatchingRepository matchingRepository;


    @Override
    public void insert() {

    }

    @Override
    public void readOne() {

    }

    @Override
    public void modify() {

    }

    @Override
    public void list() {

    }

    @Override
    public void delete() {

    }
}
