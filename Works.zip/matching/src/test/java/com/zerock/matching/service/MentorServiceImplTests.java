package com.zerock.matching.service;

import com.zerock.matching.dto.MentorDTO;
import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Log4j2
class MentorServiceImplTests {

    @Autowired
    private MentorService mentorService;

    @Test
    public void register(){         // 등록
        MentorDTO mentorDTO = MentorDTO.builder()
                .mentorId("등록1")
                .menteeId("등록1")
                .title("등록")
                .content("등록...")
                .meetingTime("등록")
                .price("등록")
                .duty("등록")
                .career("등록")
                .company("등록")
                .build();
        mentorService.register(mentorDTO);
    }

    @Test
    public void modify(){
        Long mno = 21L;
        MentorDTO mentorDTO = MentorDTO.builder()
                .menNo(mno)
                .title("수정")
                .content("수정...")
                .meetingTime("수정")
                .price("수정")
                .build();
        mentorService.modify(mentorDTO);
    }

    @Test
    public void read(){
        Long mno = 21L;
        MentorDTO mentorDTO = mentorService.readOne(mno);
        log.info("mentorDTO ====> " + mentorDTO);
    }

    @Test
    public void delete(){
        Long mno = 20L;
        mentorService.remove(mno);
    }



}