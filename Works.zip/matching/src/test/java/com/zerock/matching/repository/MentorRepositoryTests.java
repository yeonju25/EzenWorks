package com.zerock.matching.repository;

import com.zerock.matching.domain.Mentor;
import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Log4j2
class MentorRepositoryTests {

    @Autowired
    private MentorRepository mentorRepository;

    @Test
    public void insert(){
        IntStream.rangeClosed(1,20).forEach(i ->{
            Mentor mentor = Mentor.builder()
                    .mentorId("mentor" + i)
                    .menteeId("mentee" + i)
                    .title("title" + i)
                    .content("content..." + i)
                    .meetingTime("meetingTime" + i)
                    .price("price" + i)
                    .duty("duty" + i)
                    .career("career" + i)
                    .company("company" + i)
                    .build();
            mentorRepository.save(mentor);
        });
    }

}