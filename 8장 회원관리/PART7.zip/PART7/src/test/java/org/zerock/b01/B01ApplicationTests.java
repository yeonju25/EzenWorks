package org.zerock.b01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class B01ApplicationTests {

    @Test
    void contextLoads() {
    }

}
