package org.zerock.b01.domain;

public enum MemberRole {
    USER,ADMIN
    // user = 0, admin = 1
}
