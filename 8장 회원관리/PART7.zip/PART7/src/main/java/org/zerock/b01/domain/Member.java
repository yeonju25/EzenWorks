package org.zerock.b01.domain;

import lombok.*;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString(exclude = "roleSet")
public class Member {
    @Id
    private String Mid;     // id

    private String mpw;

    private String email;

    private boolean del;    // 탈퇴여부
    private boolean social; // 회원 가입 시 소셜로그인이면 true, 일반 회원가입이면 false

    @ElementCollection(fetch = FetchType.LAZY)
    @Builder.Default
    private Set<MemberRole> roleSet = new HashSet<>();

    // 28~30 대신 이렇게도 쓸 수 있다고는 한다~ 한 번 해봄
//    @Enumerated(EnumType.STRING)
//    private MemberRole memberRole;

    public void changePassword(String mpw ){
        this.mpw = mpw;
    }

    public void changeEmail(String email){
        this.email = email;
    }

    public void changeDel(boolean del){
        this.del = del;
    }

    public void addRole(MemberRole memberRole){
        this.roleSet.add(memberRole);
    }

    public void clearRoles() {
        this.roleSet.clear();
    }

    public void changeSocial(boolean social){this.social = social;}
}
